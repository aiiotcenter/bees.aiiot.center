import React from 'react'
import Missing from '../components/missing/Missing'

export default function MissingPage() {
  return (
    <>
    <Missing/>
    </>
  )
}
