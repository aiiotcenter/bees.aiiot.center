import React from 'react'

export default function WeightPage() {
  return (
    <div>WeightPage</div>
  )
}
