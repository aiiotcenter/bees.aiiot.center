import React from 'react'

export default function DiseasePage() {
  return (
    <div>DiseasePage</div>
  )
}
