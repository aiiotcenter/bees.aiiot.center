import React from 'react'

export default function Weight() {
  return (
    <div>Weight</div>
  )
}
