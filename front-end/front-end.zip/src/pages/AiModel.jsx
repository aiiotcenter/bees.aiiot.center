import React from 'react'

export default function AiModel() {
  return (
    <div>AiModel</div>
  )
}
