import React from 'react'
import Swarm from '../components/Swarm/Swarm'

export default function SwarmPage() {
  return (
    <>
      <Swarm/>
    </>
  )
}
