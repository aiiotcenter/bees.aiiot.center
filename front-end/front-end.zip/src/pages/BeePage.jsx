import React from 'react'
import BeesTypes from '../components/Bees/BeesTypes'

export default function BeePage({theme}) {
  return (
    <BeesTypes/>
  )
}
