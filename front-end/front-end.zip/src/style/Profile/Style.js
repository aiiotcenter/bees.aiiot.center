import styled from 'styled-components';

export const Wrapper = styled.div`
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  gap: 2px;
  margin-bottom: 58px;
    p{
        margin-bottom: 58px;
    }
`;