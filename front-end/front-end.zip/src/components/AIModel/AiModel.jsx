import React from 'react'
import Missing from '../missing/Missing'

export default function AiModel() {
    return (
        <>
            <Missing />
        </>
    )
}
